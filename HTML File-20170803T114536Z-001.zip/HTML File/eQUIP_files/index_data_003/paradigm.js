/* paradigm.js
* --------------------------------------------------------------------------
* Version    Date        By    Description
* --------------------------------------------------------------------------   
* 1.1        20090408    HTU   Release first version
* --------------------------------------------------------------------------   
* 
* Paradigm Systems Berhad
*/
(function(){
    var paradigm = window.paradigm = window.$psb =  function( selector, context ) {
    };
    /*
    *    escapeHTML is a function that converts HTML special characters to their 
    *    entity equivalents.
    *    sentence - set of string that need to be convert
    *    @return - converted string.
    */
    paradigm.escapeHTML = function  (sentence){
        var newSentence="";
        // restrict input to a single character
        var j=0;
        while(j < sentence.length){
            c = sentence. charAt (j);
            // loop through all possible ASCII values
            var i;
            for (i = 127; i < 160; ++ i)
                {
                    // convert i into a 2-digit hex string
                    var h = i . toString (16);
                    if (h . length == 1)
                        h = "0" + h;
                    
                    // insert a % character into the string
                    h = "%" + h;
                    
                    // determine the character represented by the escape code
                    h = unescape (h);
                    
                    // if the characters match, we've found the ASCII value
                    if (h == c)
                        break;
                }
                if(i == 160){
                    newSentence += c;
                } else{
                newSentence += "&#" + i;
            }
            j++;
        }
        
        return newSentence;
    }
})();
