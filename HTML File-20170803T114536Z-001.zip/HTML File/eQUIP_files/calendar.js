var calendarVisible = false;

var today;
var yearBegin;
var yearEnd;
var monthsText;
var daysText;
var headerText;
var headerColor;
var backgroundColor;
var previousImgSrc;
var nextImgSrc;
var transparencyImgSrc;
var slcExtDate;
var slcExtMonth;
var slcExtYear;

document.write("<span id=\"spnOuterCalendar\" style=\"position: absolute; visibility: hidden\"></span>");

function getAbsoluteLeft(obj) {
    var i = 0;
    while (obj != null) {
        i += obj.offsetLeft;
        obj = obj.offsetParent;
    }
    return i;
}

function getAbsoluteTop(obj) {
    var i = 0;
    while (obj != null) {
        i += obj.offsetTop;
        obj = obj.offsetParent;
    }
    return i;
}

function getSelectValue(select) {
    return select.options[select.selectedIndex].value;
}

function setSelectValue(select, value) {
    for (var i = 0; i < select.length; i++) {
        if (select.options[i].value == value) {
            select.options[i].selected = true;
            return true;
        }
    }
    return false;
}

function drawCalendar(month, year) {   
    if (month == -1) {
        if (year == -1) {
            month = today.getMonth() + 1;
        } else {
            month = 1;
        }
    }
    if (year == -1) {
        year = today.getFullYear();
    }

    if ((month == 1) && (year == yearBegin)) {
        document.images["previous"].style.cursor = "default";
        var width = document.images["previous"].width;
        var height = document.images["previous"].height;
        document.images["previous"].src = transparencyImgSrc;
        document.images["previous"].width = width;
        document.images["previous"].height = height;
        document.images["next"].style.cursor = "hand";
        document.images["next"].src = nextImgSrc;
    } else if ((month == 12) && (year == yearEnd)) {
        document.images["previous"].style.cursor = "hand";
        document.images["previous"].src = previousImgSrc;
        document.images["next"].style.cursor = "default";
        var width = document.images["next"].width;
        var height = document.images["next"].height;
        document.images["next"].src = transparencyImgSrc;
        document.images["next"].width = width;
        document.images["next"].height = height;
    } else {
        document.images["previous"].style.cursor = "hand";
        document.images["previous"].src = previousImgSrc;
        document.images["next"].style.cursor = "hand";
        document.images["next"].src = nextImgSrc;
    }
    setSelectValue(document.frmCalendar.slcCalendarMonth, month);
    setSelectValue(document.frmCalendar.slcCalendarYear, year);
    var spnInnerCalendar = document.getElementById('spnInnerCalendar');
    spnInnerCalendar.innerHTML = paintCalendar(month, year);
}

function hideCalendar() {
    var spnOuterCalendar = document.getElementById('spnOuterCalendar');
    spnOuterCalendar.style.visibility = "hidden";
    calendarVisible = false;
}

function paintCalendar(month, year) {
    var lastDate = 28;
    while ((new Date(year, month - 1, lastDate + 1)).getMonth() == month - 1) {
        lastDate++;
    }
    var firstDay = (new Date(year, month - 1, 1)).getDay();
    var begin = false;
    if (firstDay == 0) {
        begin = true;
    }
    var date = 1;
    var html = "";
    html += "  <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">";
    html += "    <tr>";
    html += "      <td width=\"1%\"></td>";
    html += "      <td width=\"98%\" align=\"center\"></td>";
    html += "        <table border=\"0\" width=\"100%\" cellspacing=\"2\" cellpadding=\"0\" bgcolor=\"#C0C0C0\">";
    html += "          <tr>";
    for (var i = 0; i < 7; i++) {
        html += "        <td width=\"14%\" align=\"center\" bgcolor=\"#C0C0C0\"><font face=\"arial\" color=\"" + headerColor + "\"><small><small><strong>" + days[i] + "</strong></small></small></font></td>";
    }
    html += "          </tr>";
    for (var j = 0; j < 6; j ++) {
        html+="        <tr>";
        for (var k = 0; k < 7; k ++) {
            if (begin) {
                var matchedToday = (date == today.getDate() && month == today.getMonth() + 1 && year == today.getFullYear());
                var matchedSelected = (date == getSelectValue(slcExtDate) && month == getSelectValue(slcExtMonth) && year == getSelectValue(slcExtYear));
                html += "<td width=\"14%\" align=\"center\"" + (matchedToday ? " bgcolor=\"" + headerColor + "\"" : matchedSelected ? " bgcolor=\"#800000\"" : " bgcolor=\"" + backgroundColor + "\"") + ">";
                html +=   "<a href=\"\" onclick=\"return updateExtSelect(" + date + "," + month + "," + year + ");\">";
                html +=     "<font face=\"arial\" color=\"" + (matchedToday || matchedSelected ? backgroundColor : headerColor) + "\" style=\"text-decoration: none\"><small><small>" + (matchedSelected ? "<strong>" : "") + date + (matchedSelected ? "</strong>" : "") + "</small></small></font>";
                html +=   "</a>";
                html += "</td>";
                date++;
                if (date > lastDate) {
                    begin = false;
                }
            } else {
                html += "<td width=\"14%\" align=\"center\" bgcolor=\"" + backgroundColor + "\"><font face=\"arial\"><small><small>&nbsp;</small></small></font></td>";
                if (date < lastDate && k + 1 == firstDay) {
                    begin = true;
                }
            }
        }
        html+="        </tr>";
    }
    html += "        </table>";
    html += "      </td>";
    html += "      <td width=\"1%\"></td>";
    html += "    </tr>";
    html += "  </table>";
    return html;
}

function showCalendar(left, top, date, year1, year2, months, days, header, hdcolor, bgcolor, previous, next, transparency, dateSelect, monthSelect, yearSelect) {
    if (calendarVisible) {
        hideCalendar();
    } else {

        today = date;
        yearBegin = year1;
        yearEnd = year2;
        monthsText = months;
        daysText = days;
        headerText = header;
        headerColor = hdcolor;
        backgroundColor = bgcolor
        previousImgSrc = previous;
        nextImgSrc = next;
        transparencyImgSrc = transparency;
        slcExtDate = dateSelect;
        slcExtMonth = monthSelect;
        slcExtYear = yearSelect;

        var html = "";
        html += "<form name=\"frmCalendar\">";
        html += "  <table border=\"0\" cellspacing=\"0\" cellpadding=\"1\">";
        html += "    <tr>";
        html += "      <td width=\"100%\" bgcolor=\"" + headerColor + "\">";
        html += "        <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"1\">";
        html += "          <tr>";
        html += "            <td width=\"100%\" bgcolor=\""+ backgroundColor +"\">";
        html += "              <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"3\">";
        html += "                <tr>";
        html += "                  <td colspan=\"4\" bgcolor=\"" + headerColor + "\" align=\"center\"><font face=\"arial\" color=\"" + backgroundColor + "\"><small><small><strong>" + headerText + "</strong></small></small></font></td>";
        html += "                </tr>";
        html += "                <tr>";
        html += "                  <td width=\"10%\" align=\"center\"><a href=\"\" onclick=\"return false;\"><img id=\"previous\" src=\"" + previousImgSrc + "\" alt=\"Previous Month\" border=\"0\" onclick=\"updateCalendar(-1);\"></a></td>";
        html += "                  <td width=\"40%\" align=\"center\">";
        html += "                    <select size=\"1\" name=\"slcCalendarMonth\" onchange=\"updateCalendar(0);\" style=\"font-size: 12\">";
        for (var month = 0; month < 12; month++) {
            html += "                  <option value=\"" + (month + 1) + "\">" + monthsText[month] + "</option>";
        }
        html += "                    </select>";
        html += "                  </td>";
        html += "                  <td width=\"10%\" align=\"center\"><a href=\"\" onclick=\"return false;\"><img id=\"next\" src=\"" + nextImgSrc + "\" alt=\"Next Month\" border=\"0\" onclick=\"updateCalendar(1);\"></a></td>";
        html += "                  <td width=\"40%\" align=\"center\">";
        html += "                    <select size=\"1\" name=\"slcCalendarYear\" onchange=\"updateCalendar(0);\" style=\"font-size: 12\">";
        for (var year = yearBegin; year <= yearEnd; year++) {
            html += "                  <option value=\"" + year + "\">" + year + "</option>";
        }
        html += "                   </select>";
        html += "                  </td>";
        html += "                </tr>";
        html += "              </table>";
        html += "              <span id=\"spnInnerCalendar\" style=\"width: 150\"></span>";
        html += "            </td>";
        html += "          </tr>";
        html += "        </table>";
        html += "      </td>";
        html += "    </tr>";
        html += "  </table>";
        html += "</form>";
        var spnOuterCalendar = document.getElementById('spnOuterCalendar');
        spnOuterCalendar.innerHTML = html;
        
        drawCalendar(getSelectValue(slcExtMonth), getSelectValue(slcExtYear));

        spnOuterCalendar.style.left = left;
        spnOuterCalendar.style.top = top;
        spnOuterCalendar.style.visibility = "visible";
        calendarVisible = true;
    }
}

function updateCalendar(i) {
    var year = parseInt(getSelectValue(document.frmCalendar.slcCalendarYear));
    var month = parseInt(getSelectValue(document.frmCalendar.slcCalendarMonth)) + i;
    if (month == 0) {
        month = 12;
        year--;
    } else if (month == 13) {
        month = 1;
        year++;
    }
    if ((year >= yearBegin) && (year <= yearEnd)) {
        drawCalendar(month, year);
    }
}

function updateExtSelect(date, month, year) {
    setSelectValue(slcExtDate, date);
    setSelectValue(slcExtMonth, month);
    setSelectValue(slcExtYear, year);
    hideCalendar();
    return false;
}