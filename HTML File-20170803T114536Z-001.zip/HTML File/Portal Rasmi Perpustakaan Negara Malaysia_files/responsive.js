/*
    Copyright: Vox Solutions
    Name: responsive.js
	Purpose: To toggle between desktop and mobile view by detecting the screen size and orientation
	Comment: If the server response is slow then the view appear to be hang. SOLUTION: User need to wait longer or hit the reload button.
	TODO: Preset the browser view (web/mobile/app) status and break point value in init_js and use those parameters here to resolve the problem above.
*/

$(window).load(function(){
	
	// mobile = mobile device;
	// desktop OR Tablet = Desktop device;
	
	// $(window).on("orientationchange ",function(){	
		// var o = window.orientation;
		// var w = $(window).width();
		// var h = $(window).height();

		// if (o != 90 && o != -90) {
			//here goes code for portrait...
			// alert('portrait width='+w+' height='+h);
		// } else {
			//here goes for landscape...
			
			// alert('landscape width='+w+' height='+h);
		// }
	// });
	
	// get current status
	// George: this ajax may hit server timeout or connection refuse and unable to get the browser status, thus it may not toggle the view.
	// George: if link ref js or css also hit server timeout or connection refuse then the view is distorded e.g. missing background image.
	// George: TODO: popup a button for user to refresh the page.
	//$.get( site_url("mobile/get_browser_status"), function(status) {
	status = gs_browser_status; // Modified by George to use gs_browser_view from init_js

	
		var current_url = $(location).attr('href'); // get current url
		var mobile= "mobile";
		var web= "web";
		var isTablet = false;
		var isMobile = false;
		
		if(/android|ipad|playbook|silk/i.test(navigator.userAgent))  // check is tablet device
			isTablet = true;
			
		if(/Android|BlackBerry|iPhone|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent))
			isMobile = true;
		
			// if mobile then check the session or add the mobile session.
			if(isMobile)
			{
				// Added by George to check whether rootPath i.e. base_url() is a relative path e.g. "/"
				// See http://tech-blog.maddyzone.com/javascript/get-current-url-javascript-jquery
				if (rootPath.indexOf('://') == -1) // if it is a relative path then use attr('pathname') instead of attr('href')
					current_url = $(location).attr('pathname');

				if(current_url == rootPath)
					current_url = site_url('mobile');
				
				if(current_url == site_url(''))
					current_url = current_url+'mobile';
			
				if(current_url == indexPath)
					current_url = current_url+'/mobile';
					
				if (current_url.indexOf('web') != -1) // George: if current_url contains 'web'
					//current_url = current_url.replace('/web',''); // George: let's strip it
					current_url = current_url.replace('/web','/');  // Modified by George to append '/' for 'index.php/' so that it is freindly to httrack
				
				$.post( site_url('mobile/enable_mobile'), function (data){
					
					if (data == "true") {
						window.location.href = current_url;	
					}
				});
		
			}
			else if (isTablet) //  if is tablet, mobile view in portrait and web view in landscape.
			{		
				var orientation = window.orientation;
				if( orientation == -90 || orientation == 90 )  // landscape view
				{

					//if(status != '"'+web+'"')
					if (status != "web") // Modified by George
						disable_mobile();
					
				}
				else // portrait view
				{
					//if(status != '"'+mobile+'"')
					if (status != "mobile") // Modified by George
						enable_mobile();
				}
					
				$(window).on("orientationchange",function(){
					var orientation = window.orientation;
					
					if( orientation == -90 || orientation == 90 )
					{
						//if(status != '"'+web+'"')
						if (status != "web") // Modified by George
							disable_mobile();
					}
					else
					{
						//if(status != '"'+mobile+'"')
						if (status != "mobile") // Modified by George
							enable_mobile();
					}
				});
		
			}
			else // else desktop
			{
				//if(status == '"'+mobile+'"')
				if (status == "mobile") // Modified by George
				{
					$(window).on("resize",function(){	
						detect_resize();
					});	
				}
				else
				{
					detect_resize();
					$(window).on("resize",function(){	
				
						detect_resize();
					});
				}
			}
//	});	 // Commented out by George to use gs_browser_view in init_js
});


function detect_resize()
{
	var w = $(window).width();
	
	/*
	var current_url = $(location).attr('href');	

	// George: this ajax may hit server timeout or connection refuse and unable to get the break point, thus it may not toggle the view.
	// George: if link ref js or css also hit server timeout or connection refuse then the view is distorded e.g. missing background image.
	// George: TODO: popup a button for user to refresh the page.
	$.get(site_url("mobile/get_break_point"), function(break_point) {
	
		if(w <= break_point)
		{
		//alert(break_point+' >= '+w);
			enable_mobile();
		}
		else
		{
			disable_mobile();
		}
	});	
	*/
	
	// Modified by George to use gn_break_point from init_js
		if (w <= gn_break_point)
		{
			//alert(gn_break_point+' >= '+w);
			enable_mobile();
		}
		else
		{
			disable_mobile();
		}

}

function enable_mobile()
{
	var current_url = $(location).attr('href');	

	// Added by George to check whether rootPath i.e. base_url() is a relative path e.g. "/"
	// See http://tech-blog.maddyzone.com/javascript/get-current-url-javascript-jquery
	if (rootPath.indexOf('://') == -1) // if it is a relative path then use attr('pathname') instead of attr('href')
		current_url = $(location).attr('pathname');

	if (current_url.indexOf('web') != -1)  // George: if current_url contains 'web'
		//current_url = current_url.replace('/web',''); // George: let's strip it
		current_url = current_url.replace('/web','/');  // Modified by George to append '/' for 'index.php/' so that it is freindly to httrack

	if (current_url == rootPath) // George: rootPath is base_url e.g. / or  http://epms.vox.com.my/
		current_url = site_url('mobile'); // George: become http://epms.vox.com.my/index.php/mobile
	
	if (current_url == site_url('')) // George: site_url is either index.php/ or klang.php/ e.g. http://epms.vox.com.my/index.php/
		current_url = current_url+'mobile'; // George: become http://epms.vox.com.my/index.php/mobile

	if (current_url == indexPath) // George: indexPath is either /index.php or /klang.php. Note that there is no ending '/' e.g. http://epms.vox.com.my/klang.php
		current_url = current_url+'/mobile'; // George: become http://epms.vox.com.my/klang.php/mobile
	
	$.post( site_url('mobile/enable_mobile'), function (data){
		
		if (data == "true") {
			/*
			var s = 'current_url='+current_url+'\n';
				s = s + 'rootPath=' + rootPath + '\n';
				s = s + 'site_url=' + site_url('') + '\n';
				s = s + 'indexPath=' + indexPath + '\n';	
				s = s + 'pathname=' + $(location).attr('pathname') + '\n';
			alert(s);
			*/
			window.location.href = current_url;	
			}
	});
}

function disable_mobile()
{
	var current_url = $(location).attr('href');	
	//current_url = current_url.replace('/mobile','');  // George: let's strip off '/mobile' from current_url
	current_url = current_url.replace('/mobile', '/'); // Modified by George to append '/' for 'index.php/' so that it is freindly to httrack

	$.post( site_url('mobile/disable_mobile'), function (data){
		
		if (data == "true") {
			/*
			var s = 'current_url='+current_url+'\n';
				s = s + 'rootPath=' + rootPath + '\n';
				s = s + 'site_url=' + site_url('') + '\n';
				s = s + 'indexPath=' + indexPath + '\n';	
				s = s + 'pathname=' + $(location).attr('pathname') + '\n';
			alert(s);
			*/
			window.location.href = current_url;	
		}
	});
}
