var rootPath = 'http://www.pnm.gov.my/';
var indexPage = 'index.php';
var indexPath = rootPath+'index.php';
var loggedId = '';
var loggedGuid = '';
var editorMode = 'ckeditor';
var themeName = 'admin';

var gs_browser_status = 'web';
var gn_break_point = 768;

function base_url(){
	return rootPath;
}

function root_url() {
	return 'http://www.pnm.gov.my/';
}

function site_url(url){
	return indexPath+'/'+url;	
}

function assets_path(path){
	return rootPath+'assets/'+path;
}

function get_logged_id(){
	return loggedId;
}

function get_logged_guid(){
	return loggedGuid;
}


