$(document).ready(function(){
	$(".cbox_900").colorbox({
		width:"900px", 
		height:"95%", 
		iframe:true
	});
	

	
	$('.show_tool_setting_button').click(function(){
		$(this).addClass('hidden');	
		$(this).next().removeClass('hidden');						
		$(this).closest('div').find('.tool_setting_content').removeClass('hidden');
	});

	$('.hide_tool_setting_button').click(function(){
		$(this).addClass('hidden');	
		$(this).prev().removeClass('hidden');						
		$(this).closest('div').find('.tool_setting_content').addClass('hidden');
	});	
	
	

});



function remove_color(value){
	lang_key = get_lang_key("accessibility_tools","accessibility_tools");
	is_delete = confirm(lang_key.ACCESSIBILITY_FEATURES_FONT_COLOR_DELETE_CONDIRM_MSG);
	if(is_delete == true)
	{
		id = $(value).attr('id');
		$('#'+id).remove();
	}
	else
	{
			//do ntg
	}
}

function add_font_color(){
	value = $('#font_color_picker').val();
	patt1=/^#[a-f0-9]{6}$/i;
	result = value.match(patt1);
	//Check for a hex color string '#c1c2b4'
	lang_key = get_lang_key("accessibility_tools","accessibility_tools");
	if(result == null)
	{
		alert(lang_key.ACCESSIBILITY_FEATURES_FONT_COLOR_INSERT_WRONG_MSG);
		$('#font_color_picker').val('');
	}
	else
	{
		color_id = value.replace('#','');
		if($('#font_color_'+color_id).length == 0)
		{
			$.ajax({
				type: "POST",
				url: site_url('accessibility_tools/get_font_color_block_html'),				
				data: {
					color : value
				},
				dataType: 'text',
				success: function(data){							
					$('.font_color_result').append(data);
				}
			});
		}
		else
			alert(lang_key.ACCESSIBILITY_FEATURES_FONT_COLOR_REPEACT_MSG);
		
	}
}	


function add_background_color(){
	value = $('#background_color_picker').val();
	patt1=/^#[a-f0-9]{6}$/i;
	result = value.match(patt1);
	//Check for a hex color string '#c1c2b4'
	lang_key = get_lang_key("accessibility_tools","accessibility_tools");
	if(result == null)
	{
		alert(lang_key.ACCESSIBILITY_FEATURES_BACKGROUND_COLOR_INSERT_WRONG_MSG);
		$('#background_color_picker').val('');
	}
	else
	{
		color_id = value.replace('#','');
		if($('#background_color_'+color_id).length == 0)
		{
			$.ajax({
				type: "POST",
				url: site_url('accessibility_tools/get_background_color_block_html'),				
				data: {
					color : value
				},
				dataType: 'text',
				success: function(data){							
					$('.background_color_result').append(data);
				}
			});
		}
		else
			alert(lang_key.ACCESSIBILITY_FEATURES_BACKGROUND_COLOR_REPEACT_MSG);
		
	}
}

var min=9;
var max=18;

// increase Font Size
function increaseFontSize() {
   var p = document.getElementsByTagName('p');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 18;
      }
      p[i].style.fontSize = s+"px"
   }
   var p = document.getElementsByTagName('span');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 18;
      }
      p[i].style.fontSize = s+"px"
   }
   var p = document.getElementsByTagName('input');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 18;
      }
      p[i].style.fontSize = s+"px"
   }
   var p = document.getElementsByTagName('a');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 18;
      }
      p[i].style.fontSize = s+"px"
   }
   var p = document.getElementsByTagName('font');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 18;
      }
      p[i].style.fontSize = s+"px"
   }
   
   var p = document.getElementsByTagName('label');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 18;
      }
      p[i].style.fontSize = s+"px"
   } 
    
    var p = document.getElementsByTagName('select');
    for(i=0;i<p.length;i++) {
        if(p[i].style.fontSize) {
            var s = parseInt(p[i].style.fontSize.replace("px",""));
        } else {
            var s = 12;
        }
        
        if(s!=max) {
            s = 18;
        }
        p[i].style.fontSize = s+"px"
    }
   
   update_accessibility_session('font_size','large');
}

// decrease font size
function decreaseFontSize() {
   var p = document.getElementsByTagName('p');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=min) {
         s = 9;
      }
      p[i].style.fontSize = s+"px"
   }   
   var p = document.getElementsByTagName('span');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=min) {
         s = 9;
      }
      p[i].style.fontSize = s+"px"
   }
   var p = document.getElementsByTagName('input');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=min) {
         s = 9;
      }
      p[i].style.fontSize = s+"px"
   }
   var p = document.getElementsByTagName('a');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=min) {
         s = 9;
      }
      p[i].style.fontSize = s+"px"
   }
   var p = document.getElementsByTagName('font');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=min) {
         s = 9;
      }
      p[i].style.fontSize = s+"px"
   }
   
   var p = document.getElementsByTagName('label');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=min) {
         s = 9;
      }
      p[i].style.fontSize = s+"px"
   }
    
    var p = document.getElementsByTagName('select');
    for(i=0;i<p.length;i++) {
        if(p[i].style.fontSize) {
            var s = parseInt(p[i].style.fontSize.replace("px",""));
        } else {
            var s = 12;
        }
        
        if(s!=min) {
            s = 9;
        }
        p[i].style.fontSize = s+"px"
    }
   update_accessibility_session('font_size','small');
}


// reset font size
function resetFontSize() {
   var p = document.getElementsByTagName('p');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 12;
      }else{
	 s = 12;
      }
      p[i].style.fontSize = ""
   }   
   
   var p = document.getElementsByTagName('span');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 12;
      }else{
	 s = 12;
      }
      p[i].style.fontSize = ""
   }
   
   var p = document.getElementsByTagName('input');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 12;
      }else{
	 s = 12;
      }
      p[i].style.fontSize = ""
   }
   
   var p = document.getElementsByTagName('a');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 12;
      }else{
	 s = 12;
      }
      p[i].style.fontSize = ""
   }
   
   var p = document.getElementsByTagName('font');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 12;
      }else{
	 s = 12;
      }
      p[i].style.fontSize = ""
   }
   
   var p = document.getElementsByTagName('label');
   for(i=0;i<p.length;i++) {
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
         var s = 12;
      }
      if(s!=max) {
         s = 12;
      }else{
	 s = 12;
      }
      p[i].style.fontSize = ""
   }
    
    var p = document.getElementsByTagName('select');
    for(i=0;i<p.length;i++) {
        if(p[i].style.fontSize) {
             var s = parseInt(p[i].style.fontSize.replace("px",""));
        } else {
             var s = 12;
        }
        
        if(s!=max) {
            s = 12;
        }else{
	        s = 12;
        }
        p[i].style.fontSize = ""
    }  

   update_accessibility_session('font_size','default');
}

// change color
function changeFontColor(color)
{
   var p = document.getElementsByTagName('p');
   for(i=0;i<p.length;i++) {
      p[i].style.color = color
   }   
   var p = document.getElementsByTagName('span');
   for(i=0;i<p.length;i++) {
      p[i].style.color = color
   }
   var p = document.getElementsByTagName('input');
   for(i=0;i<p.length;i++) {
      p[i].style.color = color
   }
   var p = document.getElementsByTagName('a');
   for(i=0;i<p.length;i++) {
      p[i].style.color = color
   }
   var p = document.getElementsByTagName('font');
   for(i=0;i<p.length;i++) {
      p[i].style.color = color
   }
   
   var p = document.getElementsByTagName('label');
   for(i=0;i<p.length;i++) {
      p[i].style.color = color
   }   
   
   var p = document.getElementsByTagName('td');
   for(i=0;i<p.length;i++) {
      p[i].style.color = color
   }   
   
   var p = document.getElementsByTagName('select');
   for(i=0;i<p.length;i++) {
      p[i].style.color = color
   }   
   
   update_accessibility_session('font_color',color);
}

// change font family
function changeFontType(fontType) 
{
    var x = document.getElementsByTagName("p");
    var i;
    for (i = 0; i < x.length; i++) {
        x[i].style.fontFamily = fontType;
    }  

    var x = document.getElementsByTagName("a");
    var i;
    for (i = 0; i < x.length; i++) {
        x[i].style.fontFamily = fontType;
    }  

    var x = document.getElementsByTagName("span");
    var i;
    for (i = 0; i < x.length; i++) {
        x[i].style.fontFamily = fontType;
    }
	
	var x = document.getElementsByTagName('input');
    var i;
	for(i=0;i<x.length;i++) {
	  x[i].style.fontFamily = fontType
	}
	
	var x = document.getElementsByTagName('font');
	var i;
	for(i=0;i<x.length;i++) {
	  x[i].style.fontFamily = fontType
	}

	var x = document.getElementsByTagName('label');
	var i;
	for(i=0;i<x.length;i++) {
	  x[i].style.fontFamily = fontType
	}   

	var x = document.getElementsByTagName('td');
	var i;
	for(i=0;i<x.length;i++) {
	  x[i].style.fontFamily = fontType
	}   

	var x = document.getElementsByTagName('select');
	var i;
	for(i=0;i<x.length;i++) {
	  x[i].style.fontFamily = fontType
	}   
}


function changeBackgroundColor(color)
{						
	$('#body_web').css('background-color',color);	
	$('#body_web').css('background-image','none');
	update_accessibility_session('background_color',color);
}


function changeContrast(type)
{
	if(type == "dark")
	{
		$('#body_web').find('div,p,label,span').each(function(){	
			if(!$(this).hasClass('accessibility_block'))
			{	
				$(this).addClass('contrast_dark');
				$(this).removeClass('contrast_light');
			}
		});
	}
	else if(type == "light")
	{	
		$('#body_web').find('div,p,label,span').each(function(){	
			if(!$(this).hasClass('accessibility_block')){
				$(this).removeClass('contrast_dark');
				$(this).addClass('contrast_light');
			}
		});
	}
	else 
	{
		$('#body_web').find('div,p,label,span').each(function(){		
			$(this).removeClass('contrast_dark');
			$(this).removeClass('contrast_light');
		});
	}	
	update_accessibility_session('contrast',type);
}



function changeLayoutSize(type)
{
	id = $('div').first().attr('id');
	if(type == "default")
	{
		$('#'+id).removeClass('layout_thin');
		$('#'+id).removeClass('layout_wide');
	}
	else if(type == "wide")
	{
		$('#'+id).removeClass('layout_thin');
		$('#'+id).addClass('layout_wide');
	}
	else{
		$('#'+id).addClass('layout_thin');
		$('#'+id).removeClass('layout_wide');	
	}
	update_accessibility_session('layout_size',type);
}




function changeBackground(background)
{
	$.ajax({
		url: site_url('themes/load_cms_background/'+background),
		type: 'POST',
		dataType: 'json',
		success: function(data){
			
			//if(data.background_enabled == true)			
				$('#body_web').css('background-image','url('+data.image_path+data.background_image+')');
			//else
			//	$('#body_web').css('background-image','none');
				$('#body_web').css('background-repeat',data.background_repeat);
				$('#body_web').css('background-position',data.background_position);
				$('#body_web').css('background-attachment',data.background_attachment);
				if(data.background_transparent == true)
					$('#body_web').css('background-color','none');
				else
					$('#body_web').css('background-color',data.background_color);
				
		
		}			
	});	
	update_accessibility_session('background_image',background);
}


function refreshAccessibility()
{
	$.ajax({
		url: site_url('accessibility_tools/clear_tool_session'),
		type: 'POST',
		dataType: 'json',
		success: function(data){			
			window.location.reload();
		}			
	});	
}




function load_accessibility_tool(block_id)
{
	$.ajax({
		url: site_url('accessibility_tools/get_tool_session'),
		type: 'POST',
		data : {
			'block_id' : block_id,			
		},
		dataType: 'json',
		success: function(data){
			
			if(data.font_size != "")
			{
				if(data.font_size == "large")
				{				
					increaseFontSize();
				}
				else if (data.font_size == "default")
					resetFontSize();
				else
					decreaseFontSize();
			}
			
			if(data.font_color != "")
				changeFontColor(data.font_color);
				
			if(data.background_color != "")
				changeBackgroundColor(data.background_color);
			
			if(data.background_image != "")
				changeBackground(data.background_image);
				
			if(data.layout_size != "")
				changeLayoutSize(data.layout_size);

			if(data.contrast != "")
				changeContrast(data.contrast);
		}			
	});		
}



function update_accessibility_session(module,value)
{
	$.ajax({
		url: site_url('accessibility_tools/set_tool_session'),
		type: 'POST',
		data : {
			'module' : module,
			'value' : value
		},
		dataType: 'json',
		success: function(data){
			//do ntg
		}			
	});		
}


function init_theme_background_container(value)
{
	if(value == true)
	{
		$('.background_color_container').addClass('hidden');
	}
	else
		$('.background_color_container').removeClass('hidden');
}


function check_bg_transparent()
{
	value = $('#background_transparent_checkbox').attr('checked');	
	if(value == "checked")
	{
		$('.background_color_container').addClass('hidden');
	}
	else
		$('.background_color_container').removeClass('hidden');	
}


